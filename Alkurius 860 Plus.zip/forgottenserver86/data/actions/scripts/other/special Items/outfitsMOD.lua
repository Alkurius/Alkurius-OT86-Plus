
local config = {
	[13031] = {Male = 370,  Female = 377, Addon = 0, description = "Retro Citizen Outfit"},
	[13032] = {Male = 371,  Female = 378, Addon = 0, description = "Retro Hunter Outfit"},
	[13033] = {Male = 372,  Female = 379, Addon = 0, description = "Retro Mage Outfit"},
	[13034] = {Male = 373,  Female = 380, Addon = 0, description = "Retro Knight Outfit"},
	[13035] = {Male = 374,  Female = 381, Addon = 0, description = "Retro Nobleman Outfit"},
	[13036] = {Male = 375,  Female = 382, Addon = 0, description = "Retro Summoner Outfit"},
	[13037] = {Male = 376,  Female = 383, Addon = 0, description = "Retro Warrior Outfit"},
	[13038] = {Male = 385,  Female = 385, Addon = 1, description = "Golden Outfit"}

}

function onUse(cid, item, fromPosition, itemEx, toPosition)	
	local Outfits = config[item.itemid]
	if not Outfits then
		return true
	end
	
	Player(cid):sendTextMessage(MESSAGE_EVENT_ADVANCE, "You got " .. Outfits.description)
	Player(cid):addOutfit(Outfits.Female, 0)
	Player(cid):addOutfit(Outfits.Male, 0)
	
	if Outfits.Addon == 1 then
		Player(cid):addOutfitAddon(Outfits.Female, 3)
		Player(cid):addOutfitAddon(Outfits.Male, 3)
	end	
	
	Item(item.uid):remove(1)
	fromPosition:sendMagicEffect(CONST_ME_GIFT_WRAPS)
	return true
end