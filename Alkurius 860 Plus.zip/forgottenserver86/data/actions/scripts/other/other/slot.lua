function onUse(player, item, fromPosition, itemEx, toPosition)
return stat_onUse(player, item, fromPosition, itemEx, toPosition)
end