dofile('data/lib/quests/demon_oak.lua')
dofile('data/lib/quests/killing_in_the_name_of.lua')
dofile('data/lib/quests/svargrond_arena.lua')

